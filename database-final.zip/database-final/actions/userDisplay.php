<html>
 <head>
  <title>user</title>
  <style type="text/css">
    body{
      background-image: url('../assets/img/bg.jpg');

    }
   
    .button {
  padding: 15px 25px;
  font-size: 24px;
  text-align: center;
  cursor: pointer;
  outline: none;
  color: #fff;
  background-color: #f44336;
  border: none;
  border-radius: 15px;
  
}

.button:hover {background-color: #f44336;}

.button:active {
  background-color: #f44336;
  
  transform: translateY(4px);
}
  </style>
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link href="../assets/css/userInfo.css" rel="stylesheet"/>
 </head>
 <body>

 
 
 <?php
// PHP code just started
function getuserid($id){
  $res="user_";
  for($i=0;$i< 6-strlen($id);$i++){
    $res.="0";
  }
  $res.=$id;
  return $res;
}
function ShowUser(){
  $dbhost='localhost';
  $dbuser='root';
  $dbpass='123456';
  $dbname='final';
  $mysqli=new mysqli($dbhost,$dbuser,$dbpass,$dbname);
  $userID=getuserid($_POST["userid"]);

  if(!$mysqli){
    echo "connection failed\n";
  }
  
  $query="CALL ShowUser('$userID')";
  $res=mysqli_query($mysqli,$query);
  $columns=mysqli_num_fields($res);
  $row=mysqli_fetch_row($res);
  echo "<div style='position: absolute;
  margin: 200px 140px;'>
  <div class='w3-row' >";
  $i=0;
  while($field=$res->fetch_field()){
                    switch($i){
                    	case 0:
                    		echo "<div class='w3-col w3-container' style='width:160px'> ";
                    		break;
                    	case 1:
                    		echo "<div class='w3-col w3-container' style='width:250px'> ";
                    		break;
                    	case 2:
                    		echo "<div class='w3-col w3-container' style='width:160px'> ";
                    		break;
                    	case 3:
                    		echo "<div class='w3-col w3-container' style='width:180px'> ";
                    		break;
                    	case 4:
                    		echo "<div class='w3-col w3-container' style='width:300px'> ";
                    		break;
                    }
                   	echo"
                   <div class='card'>
                            <div class='content'>
                                <div class='row'>  
                                    <div class='col-xs-7'>
                                        <div class='numbers'>";
                                            echo "<p> {$field->name} </p>
                                            <hr />
                                            $row[$i]";
                                            $i++;

                                     echo "</div>
                                    </div>
                                </div>
                            </div>
                       </div>*/ 
                        </div>";
                    
  }

  echo "</div>
  </div>
 ";
 session_start();
$_SESSION['curUserID'] = $row[1];

   echo "<div style='position: absolute;
  margin: 450px 480px;'><div class='w3-row'>
<form action='userhabbit.php' >
	  <button class='button' type='submit'>One Click to know more</button>
</form>
  </div></div>";
}
ShowUser();

// PHP code about to end

 ?>



 </body>
</html>