<html>
 <head>
  <title>user</title>
  <style type="text/css">
    body{
      background-image: url('../assets/img/bg.jpg');

    }
   
    .button {
  padding: 15px 25px;
  font-size: 24px;
  text-align: center;
  cursor: pointer;
  outline: none;
  color: #fff;
  background-color: #f44336;
  border: none;
  border-radius: 15px;
  
}

.button:hover {background-color: #f44336;}

.button:active {
  background-color: #f44336;
  
  transform: translateY(4px);
}
  </style>
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link href="../assets/css/userInfo.css" rel="stylesheet"/>
 </head>
 <body>

 
 
 <?php
// PHP code just started

function ShowSong(){
  $dbhost='localhost';
  $dbuser='root';
  $dbpass='123456';
  $dbname='final';
  $mysqli=new mysqli($dbhost,$dbuser,$dbpass,$dbname);


  if(!$mysqli){
    echo "connection failed\n";
  }
  session_start();
  $id=$_SESSION['SongID'];
  $query="CALL ShowSongPlayTime('$id')";
  $res=mysqli_query($mysqli,$query);
  $columns=mysqli_num_fields($res);
  $row=mysqli_fetch_row($res);
  echo "<div style='position: absolute;margin: 200px 800px;'>
    <div class='w3-col w3-container' style='width:300px'>
        <div class='card'>
              <div class='content'>
                  <div class='row'>  
                      <div class='col-xs-7'>
                           <div class='numbers'>
                              <p> Play Times </p>
                                            <hr />
                                            $row[0]
                                          </div>
                                    </div>
                                </div>
                            </div>
                       </div> 
                    </div>
                    </div>";
  $dbhost='localhost';
  $dbuser='root';
  $dbpass='123456';
  $dbname='final';
  $mysqli=new mysqli($dbhost,$dbuser,$dbpass,$dbname);
 

  if(!$mysqli){
    echo "connection failed\n";
  }
  $query="CALL ShowListenTime('$id')";
  $re=mysqli_query($mysqli,$query);
  $columns=mysqli_num_fields($re);
  $row=mysqli_fetch_row($re);
  echo "<div style='position: absolute;margin: 200px 400px;'>
    <div class='w3-col w3-container' style='width:300px'>
        <div class='card'>
              <div class='content'>
                  <div class='row'>  
                      <div class='col-xs-7'>
                           <div class='numbers'>
                              <p> People like to listen this song in... </p>
                                            <hr />
                                            $row[0]
                                          </div>
                                    </div>
                                </div>
                            </div>
                       </div> 
                    </div>
                    </div>";
}
ShowSong();

// PHP code about to end

 ?>



 </body>
</html>